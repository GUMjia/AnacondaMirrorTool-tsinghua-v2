[CmdletBinding()]
param(
    [ValidateSet("Menu", "Apply", "Restore")]
    [string]$Action = "Menu",
    [string]$CondaRoot,
    [string]$DesktopDirectory,
    [string]$StatePath
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$MirrorRoot = "https://mirrors.tuna.tsinghua.edu.cn/anaconda"
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Write-Section {
    param([string]$Text)
    Write-Host ""
    Write-Host "==> $Text" -ForegroundColor Cyan
}

function Expand-PathSafe {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) {
        return $null
    }
    return [Environment]::ExpandEnvironmentVariables($Path.Trim().Trim('"'))
}

function Test-PathSafe {
    param([string]$Path)
    if (-not $Path) {
        return $false
    }
    try {
        return Test-Path -LiteralPath $Path -PathType Leaf
    }
    catch {
        return $false
    }
}

function Test-AnacondaRoot {
    param([string]$Path)

    $expanded = Expand-PathSafe $Path
    if (-not $expanded) {
        return $false
    }

    $condaBat = Join-Path $expanded "condabin\conda.bat"
    $activateBat = Join-Path $expanded "Scripts\activate.bat"
    return (
        (Test-PathSafe $condaBat) -and
        (Test-PathSafe $activateBat)
    )
}

function Add-Candidate {
    param(
        [System.Collections.Generic.List[string]]$Candidates,
        [string]$Path
    )

    $expanded = Expand-PathSafe $Path
    if (-not $expanded) {
        return
    }
    try {
        $fullPath = [System.IO.Path]::GetFullPath($expanded)
    }
    catch {
        return
    }

    if (-not ($Candidates | Where-Object { $_.Equals($fullPath, [System.StringComparison]::OrdinalIgnoreCase) })) {
        $Candidates.Add($fullPath)
    }
}

function Get-ObjectPropertyValue {
    param(
        [object]$Object,
        [string]$Name
    )
    if ($null -eq $Object) {
        return $null
    }
    $property = $Object.PSObject.Properties[$Name]
    if ($null -eq $property) {
        return $null
    }
    return $property.Value
}

function Add-CandidateFromText {
    param(
        [System.Collections.Generic.List[string]]$Candidates,
        [string]$Text
    )
    if (-not $Text) {
        return
    }

    foreach ($pattern in @(
        '([A-Za-z]:\\[^"\r\n]+?)\\Scripts\\activate\.bat',
        '([A-Za-z]:\\[^"\r\n]+?)\\condabin\\conda\.bat',
        '([A-Za-z]:\\[^"\r\n]+?)\\(?:pythonw?\.exe|Scripts\\anaconda-navigator-script\.py)'
    )) {
        foreach ($match in [regex]::Matches($Text, $pattern, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            Add-Candidate $Candidates $match.Groups[1].Value
        }
    }
}

function Add-StartMenuCandidates {
    param([System.Collections.Generic.List[string]]$Candidates)

    $shell = New-Object -ComObject WScript.Shell
    foreach ($startRoot in @(
        (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"),
        (Join-Path $env:ProgramData "Microsoft\Windows\Start Menu\Programs")
    )) {
        if (-not (Test-Path -LiteralPath $startRoot)) {
            continue
        }
        Get-ChildItem -LiteralPath $startRoot -Recurse -Filter "*.lnk" -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match "Anaconda|Miniconda|Conda" } |
            ForEach-Object {
                try {
                    $shortcut = $shell.CreateShortcut($_.FullName)
                    Add-CandidateFromText $Candidates $shortcut.TargetPath
                    Add-CandidateFromText $Candidates $shortcut.Arguments

                    $targetParent = Split-Path -Parent $shortcut.TargetPath
                    $targetLeaf = Split-Path -Leaf $shortcut.TargetPath
                    if ($targetLeaf -match "^(python|pythonw|conda)\.exe$" -and $targetParent) {
                        $parentLeaf = Split-Path -Leaf $targetParent
                        if ($parentLeaf -match "^(Scripts|condabin)$") {
                            Add-Candidate $Candidates (Split-Path -Parent $targetParent)
                        }
                        else {
                            Add-Candidate $Candidates $targetParent
                        }
                    }
                }
                catch {
                    # Ignore shortcuts that Windows will not allow us to inspect.
                }
            }
    }
}

function Find-AnacondaRoots {
    $candidates = New-Object "System.Collections.Generic.List[string]"

    foreach ($path in @(
        $env:CONDA_PREFIX,
        (Join-Path $env:USERPROFILE "anaconda3"),
        (Join-Path $env:USERPROFILE "Anaconda3"),
        (Join-Path $env:USERPROFILE "miniconda3"),
        (Join-Path $env:USERPROFILE "Miniconda3"),
        (Join-Path $env:LOCALAPPDATA "anaconda3"),
        (Join-Path $env:LOCALAPPDATA "Programs\anaconda3"),
        "C:\ProgramData\anaconda3",
        "C:\ProgramData\Anaconda3",
        "C:\ProgramData\miniconda3",
        "C:\ProgramData\Miniconda3",
        "C:\Anaconda3",
        "C:\Miniconda3",
        "C:\Program Files\Anaconda3",
        "C:\Program Files\Miniconda3"
    )) {
        Add-Candidate $candidates $path
    }

    $condaCommand = Get-Command "conda.exe" -ErrorAction SilentlyContinue
    if ($condaCommand -and $condaCommand.Path) {
        Add-Candidate $candidates (Split-Path -Parent (Split-Path -Parent $condaCommand.Path))
    }

    foreach ($entry in ($env:Path -split ";")) {
        if ($entry -and (Split-Path -Leaf $entry) -match "^(Scripts|condabin)$") {
            Add-Candidate $candidates (Split-Path -Parent $entry)
        }
    }

    Add-StartMenuCandidates $candidates

    foreach ($registryRoot in @(
        "HKCU:\Software\Python\ContinuumAnalytics",
        "HKLM:\Software\Python\ContinuumAnalytics",
        "HKLM:\Software\WOW6432Node\Python\ContinuumAnalytics"
    )) {
        if (-not (Test-Path -LiteralPath $registryRoot)) {
            continue
        }
        Get-ChildItem -LiteralPath $registryRoot -ErrorAction SilentlyContinue | ForEach-Object {
            $properties = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue
            $installPath = Get-ObjectPropertyValue $properties "InstallPath"
            Add-Candidate $candidates $installPath
        }
    }

    foreach ($uninstallRoot in @(
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall",
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall",
        "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
    )) {
        if (-not (Test-Path -LiteralPath $uninstallRoot)) {
            continue
        }
        Get-ChildItem -LiteralPath $uninstallRoot -ErrorAction SilentlyContinue | ForEach-Object {
            $properties = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue
            $displayName = Get-ObjectPropertyValue $properties "DisplayName"
            $installLocation = Get-ObjectPropertyValue $properties "InstallLocation"
            if ($displayName -match "Anaconda|Miniconda" -and $installLocation) {
                Add-Candidate $candidates $installLocation
            }
        }
    }

    return @($candidates | Where-Object { Test-AnacondaRoot $_ })
}

function Select-AnacondaRoot {
    param([string[]]$Roots)

    if ($Roots.Count -eq 1) {
        return $Roots[0]
    }

    Write-Host ""
    Write-Host "Multiple Anaconda/Miniconda installations were found:" -ForegroundColor Yellow
    for ($i = 0; $i -lt $Roots.Count; $i++) {
        Write-Host ("  [{0}] {1}" -f ($i + 1), $Roots[$i])
    }
    $answer = Read-Host "Select an installation number [1]"
    if ([string]::IsNullOrWhiteSpace($answer)) {
        return $Roots[0]
    }

    $index = 0
    if (-not [int]::TryParse($answer, [ref]$index) -or $index -lt 1 -or $index -gt $Roots.Count) {
        throw "Invalid installation selection."
    }
    return $Roots[$index - 1]
}

function Select-FolderManually {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = "Select the Anaconda installation folder"
    $dialog.ShowNewFolderButton = $false
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        return $null
    }
    return $dialog.SelectedPath
}

function Resolve-CondaRoot {
    if ($CondaRoot) {
        if (-not (Test-AnacondaRoot $CondaRoot)) {
            throw "Not a valid Anaconda root: $CondaRoot"
        }
        return [System.IO.Path]::GetFullPath((Expand-PathSafe $CondaRoot))
    }

    $roots = @(Find-AnacondaRoots)
    if ($roots.Count -eq 0) {
        Write-Warning "Anaconda was not found automatically."
        $manual = Select-FolderManually
        if (-not $manual -or -not (Test-AnacondaRoot $manual)) {
            throw "No valid Anaconda installation was selected."
        }
        return [System.IO.Path]::GetFullPath($manual)
    }
    return Select-AnacondaRoot $roots
}

function Get-MirrorConfigText {
    return @"
channels:
  - defaults

show_channel_urls: true

default_channels:
  - $MirrorRoot/pkgs/main
  - $MirrorRoot/pkgs/r
  - $MirrorRoot/pkgs/msys2

channel_alias: $MirrorRoot/cloud
"@
}

function Get-FileSha256 {
    param([string]$Path)
    $hash = Get-FileHash -LiteralPath $Path -Algorithm SHA256
    return $hash.Hash
}

function Get-TextSha256 {
    param([string]$Text)
    $bytes = $Utf8NoBom.GetBytes($Text)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace("-", "")
    }
    finally {
        $sha.Dispose()
    }
}

function Normalize-ConfigText {
    param([string]$Text)
    if ($null -eq $Text) {
        return ""
    }
    return ($Text -replace "`r`n", "`n").Trim()
}

function Get-StatePath {
    param([string]$Root)
    if ($StatePath) {
        return [System.IO.Path]::GetFullPath((Expand-PathSafe $StatePath))
    }
    return Join-Path $Root ".conda-fast-state.json"
}

function Read-State {
    param([string]$Path)
    if (-not (Test-PathSafe $Path)) {
        return $null
    }
    return Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
}

function Write-State {
    param(
        [string]$Path,
        [string]$Root,
        [string]$CondaConfig,
        [bool]$ExistedBefore,
        [string]$BackupPath,
        [string]$AppliedSha256
    )

    $state = [ordered]@{
        Version = 1
        CondaRoot = $Root
        CondaConfig = $CondaConfig
        ExistedBefore = $ExistedBefore
        BackupPath = $BackupPath
        AppliedSha256 = $AppliedSha256
        AppliedAt = (Get-Date).ToString("o")
    }
    $json = $state | ConvertTo-Json
    [System.IO.File]::WriteAllText($Path, $json, $Utf8NoBom)
}

function New-NavigatorShortcut {
    param([string]$Root)

    $pythonw = Join-Path $Root "pythonw.exe"
    $cwp = Join-Path $Root "cwp.py"
    $navigator = Join-Path $Root "Scripts\anaconda-navigator-script.py"
    if (
        -not (Test-PathSafe $pythonw) -or
        -not (Test-PathSafe $cwp) -or
        -not (Test-PathSafe $navigator)
    ) {
        Write-Warning "Anaconda Navigator files were not found; no desktop shortcut was created."
        return $false
    }

    if (-not $DesktopDirectory) {
        $DesktopDirectory = [Environment]::GetFolderPath("Desktop")
    }
    if (-not $DesktopDirectory -or -not (Test-Path -LiteralPath $DesktopDirectory -PathType Container)) {
        throw "Desktop directory was not found."
    }
    $DesktopDirectory = [System.IO.Path]::GetFullPath($DesktopDirectory)
    $shortcutPath = Join-Path $DesktopDirectory "Anaconda Navigator.lnk"

    $icon = Join-Path $Root "Menu\anaconda-navigator.ico"
    if (-not (Test-PathSafe $icon)) {
        $icon = $pythonw
    }

    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $pythonw
    $shortcut.Arguments = "`"$cwp`" `"$Root`" `"$pythonw`" `"$navigator`""
    $shortcut.WorkingDirectory = $env:USERPROFILE
    $shortcut.IconLocation = "$icon,0"
    $shortcut.Description = "Anaconda Navigator"
    $shortcut.WindowStyle = 1
    $shortcut.Save()

    Write-Host "Desktop shortcut: $shortcutPath" -ForegroundColor Green
    return $true
}

function Show-Status {
    param([string]$Root)
    $configPath = Join-Path $Root ".condarc"
    $stateFile = Get-StatePath $Root
    $hasMirror = $false
    if (Test-PathSafe $configPath) {
        $content = Get-Content -LiteralPath $configPath -Raw
        $hasMirror = $content.Contains($MirrorRoot)
    }
    Write-Host "Anaconda root: $Root"
    Write-Host "Config file:   $configPath"
    Write-Host "Mirror status: $(if ($hasMirror) { 'TUNA enabled' } else { 'not enabled' })"
    Write-Host "Undo state:    $(if (Test-PathSafe $stateFile) { 'available' } else { 'not available' })"
}

function Invoke-Apply {
    param([string]$Root)
    Write-Section "Applying Tsinghua mirror directly to the Anaconda directory"

    $configPath = Join-Path $Root ".condarc"
    $stateFile = Get-StatePath $Root
    $backupPath = Join-Path $Root ".condarc.conda-fast-backup"
    $mirrorText = Get-MirrorConfigText
    $mirrorHash = Get-TextSha256 $mirrorText
    $existingState = Read-State $stateFile
    $configExists = Test-PathSafe $configPath
    $existedBefore = $configExists

    if ($existingState) {
        $currentHash = if ($configExists) { Get-FileSha256 $configPath } else { $null }
        if ($currentHash -and $currentHash.Equals($existingState.AppliedSha256, [System.StringComparison]::OrdinalIgnoreCase)) {
            $existedBefore = [bool]$existingState.ExistedBefore
        }
        elseif ($configExists) {
            Copy-Item -LiteralPath $configPath -Destination $backupPath -Force
            $existedBefore = $true
        }
        else {
            $existedBefore = $false
        }
    }
    elseif ($configExists) {
        $currentText = Get-Content -LiteralPath $configPath -Raw
        if (
            (Normalize-ConfigText $currentText) -eq
            (Normalize-ConfigText $mirrorText)
        ) {
            # The previous helper version may already have created this exact config.
            $existedBefore = $false
        }
        else {
            Copy-Item -LiteralPath $configPath -Destination $backupPath -Force
        }
    }

    try {
        [System.IO.File]::WriteAllText($configPath, $mirrorText, $Utf8NoBom)
        Write-State `
            -Path $stateFile `
            -Root $Root `
            -CondaConfig $configPath `
            -ExistedBefore $existedBefore `
            -BackupPath $backupPath `
            -AppliedSha256 $mirrorHash
    }
    catch {
        $applyError = $_.Exception
        try {
            if ($existedBefore -and (Test-PathSafe $backupPath)) {
                Copy-Item -LiteralPath $backupPath -Destination $configPath -Force
            }
            elseif (-not $existedBefore -and (Test-PathSafe $configPath)) {
                Remove-Item -LiteralPath $configPath -Force
            }
        }
        catch {
            # Preserve the original error below.
        }
        if ($applyError -is [System.UnauthorizedAccessException]) {
            throw "Cannot write $configPath. Right-click Run-AnacondaMirror.cmd and choose Run as administrator."
        }
        throw $applyError
    }

    $writtenHash = Get-FileSha256 $configPath
    if (-not $writtenHash.Equals($mirrorHash, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "The mirror configuration was not written correctly."
    }

    Write-Host "Mirror configuration applied." -ForegroundColor Green
    if ($existedBefore) {
        Write-Host "Original config backup: $backupPath"
    }
    else {
        Write-Host "No previous .condarc existed. Undo will remove the generated file."
    }
    New-NavigatorShortcut $Root | Out-Null
}

function Invoke-Restore {
    param([string]$Root)
    Write-Section "Restoring the previous Anaconda configuration"

    $configPath = Join-Path $Root ".condarc"
    $stateFile = Get-StatePath $Root
    $state = Read-State $stateFile
    if (-not $state) {
        throw "No undo state was found for this Anaconda installation. Nothing was restored."
    }

    $savedConfigPath = [System.IO.Path]::GetFullPath((Expand-PathSafe $state.CondaConfig))
    if (-not $configPath.Equals($savedConfigPath, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "The saved undo state belongs to a different Conda configuration file."
    }

    $configExists = Test-PathSafe $configPath
    $currentHash = if ($configExists) { Get-FileSha256 $configPath } else { $null }
    if (
        -not $currentHash -or
        -not $currentHash.Equals($state.AppliedSha256, [System.StringComparison]::OrdinalIgnoreCase)
    ) {
        throw "The .condarc file was changed after the mirror was applied. Undo stopped to avoid overwriting those changes."
    }

    try {
        if ([bool]$state.ExistedBefore) {
            if (-not (Test-PathSafe $state.BackupPath)) {
                throw "The original .condarc backup is missing: $($state.BackupPath)"
            }
            Copy-Item -LiteralPath $state.BackupPath -Destination $configPath -Force
            Write-Host "Original .condarc restored from backup." -ForegroundColor Green
        }
        else {
            Remove-Item -LiteralPath $configPath -Force
            Write-Host "Generated .condarc removed." -ForegroundColor Green
        }
        Remove-Item -LiteralPath $stateFile -Force
        Write-Host "Undo state cleared. The Navigator desktop shortcut was kept." -ForegroundColor Green
    }
    catch [System.UnauthorizedAccessException] {
        throw "Cannot restore $configPath. Right-click Run-AnacondaMirror.cmd and choose Run as administrator."
    }
}

function Invoke-Menu {
    $root = Resolve-CondaRoot
    while ($true) {
        Show-Status $root
        Write-Host ""
        Write-Host "1. Enable Tsinghua mirror and create Navigator shortcut"
        Write-Host "2. Restore the configuration saved before applying the mirror"
        Write-Host "3. Select a different Anaconda installation folder"
        Write-Host "0. Exit"
        $choice = Read-Host "Enter 1, 2, 3, or 0"

        switch ($choice.Trim()) {
            "1" { Invoke-Apply $root; return }
            "2" { Invoke-Restore $root; return }
            "3" {
                $manual = Select-FolderManually
                if ($manual -and (Test-AnacondaRoot $manual)) {
                    $root = [System.IO.Path]::GetFullPath($manual)
                }
                else {
                    Write-Warning "The selected folder is not a valid Anaconda installation."
                }
            }
            "0" { return }
            default { Write-Warning "Invalid selection." }
        }
    }
}

try {
    if ($Action -eq "Apply" -or $Action -eq "Restore") {
        $root = Resolve-CondaRoot
        if ($Action -eq "Apply") {
            Invoke-Apply $root
        }
        else {
            Invoke-Restore $root
        }
    }
    else {
        Invoke-Menu
    }
    exit 0
}
catch {
    Write-Host ""
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
