Anaconda 清华镜像管理工具
========================

用途
----
直接修改 Anaconda 安装目录中的 .condarc，不修改 CONDARC 环境变量，
不创建 Anaconda Prompt 快捷方式。

使用方法
--------
1. 双击 Run-AnacondaMirror.cmd。
2. 如果找到多个安装，按提示输入编号。
3. 按 1：启用清华镜像，并在桌面创建 Anaconda Navigator 快捷方式。
4. 按 2：恢复到按 1 之前的配置。
5. 按 3：手动选择其他安装目录。

自动查找范围
------------
- 常用 Anaconda/Miniconda 安装位置
- 系统 PATH 和环境变量
- Windows 开始菜单中的 Anaconda/Conda 快捷方式
- Anaconda 注册表安装信息

如果仍找不到，可以在菜单中按 3 手动选择 Anaconda 安装目录。

修改位置
--------
Anaconda 安装目录\.condarc

安全措施
--------
- 修改前会把原 .condarc 备份为：
  Anaconda 安装目录\.condarc.conda-fast-backup
- 撤回状态保存在：
  Anaconda 安装目录\.conda-fast-state.json
- 如果原来的安装目录没有 .condarc，按 2 会删除工具生成的文件。
- 如果应用镜像后手动修改过 .condarc，撤回会停止，避免覆盖你的修改。
- 撤回镜像配置不会删除桌面上的 Navigator 快捷方式。

权限
----
安装在用户目录时通常不需要管理员权限。
如果提示拒绝访问，请右键 Run-AnacondaMirror.cmd，选择“以管理员身份运行”。

注意事项
--------
- 工具不会修改系统或用户 Conda 环境变量。
- 如果其他软件强制设置了 Conda 通道，配置可能被覆盖。
- 完整安装包通常比软件内置的跨版本更新更快。
